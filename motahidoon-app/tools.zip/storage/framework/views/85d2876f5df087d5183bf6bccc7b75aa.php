
<!doctype html>
<html lang="<?php echo e($meta['lang']); ?>" dir="<?php echo e($meta['dir']); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title><?php echo e($meta['title']); ?></title>
  <meta name="description" content="<?php echo e($meta['description']); ?>">
  <meta name="theme-color" content="#0C7B3F">
  <link rel="icon" href="<?php echo e(asset('assets/img/logos/mutahidoon-mark.png')); ?>">

  <meta property="og:type" content="website">
  <meta property="og:title" content="<?php echo e($meta['title']); ?>">
  <meta property="og:description" content="<?php echo e($meta['description']); ?>">
  <meta property="og:image" content="<?php echo e(asset($meta['image'])); ?>">
  <meta property="og:url" content="<?php echo e(url()->current()); ?>">
  <meta property="og:locale" content="<?php echo e($meta['ogLocale']); ?>">
  <meta name="twitter:card" content="summary_large_image">

  <?php $__currentLoopData = $meta['alternates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $href): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <link rel="alternate" hreflang="<?php echo e($code); ?>" href="<?php echo e($href); ?>">
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <link rel="canonical" href="<?php echo e($meta['canonical']); ?>">


  
  <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/site.tsx']); ?>
  <?php $__inertiaSsrResponse = app(\Inertia\Ssr\SsrState::class)->setPage($page)->dispatch();  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
</head>
<body>
  <noscript>
    <p style="padding:2rem;text-align:center">هذا الموقع يحتاج تفعيل الجافاسكربت لعرض المحتوى.</p>
  </noscript>
  <?php $__inertiaSsrResponse = app(\Inertia\Ssr\SsrState::class)->setPage($page)->dispatch();  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><script data-page="app" type="application/json"><?php echo json_encode($page, JSON_HEX_TAG); ?></script><div id="app"></div><?php } ?>
</body>
</html>
<?php /**PATH D:\2026\motahedoon\motahidoon-app\resources\views/site.blade.php ENDPATH**/ ?>