<?php

namespace Tests\Feature;

use Database\Seeders\ContentSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ExampleTest extends TestCase
{
    use RefreshDatabase;

    /** الرئيسية تقرأ من القاعدة الآن، فتحتاج المحتوى مستورَداً. */
    public function test_the_application_returns_a_successful_response(): void
    {
        $this->seed(ContentSeeder::class);

        $this->get('/')->assertStatus(200);
    }
}
