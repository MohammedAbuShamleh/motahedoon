<?php

namespace App\Enums;

/** مجموعات أسطر المتن الدائم — القيم مطابقة لعمود content_lines.group. */
enum ContentLineGroup: string
{
    case Value = 'value';
    case Story = 'story';
    case Goal = 'goal';
    case Aspiration = 'aspiration';
    case Intro = 'intro';

    public function label(): string
    {
        return match ($this) {
            self::Value => 'القيم',
            self::Story => 'قصة التأسيس',
            self::Goal => 'الأهداف',
            self::Aspiration => 'التطلّعات',
            self::Intro => 'المقدّمة',
        };
    }

    /** أين تظهر المجموعة في الموقع، ليعرف المحرّر أيّ سطر يغيّر أيّ قسم. */
    public function hint(): ?string
    {
        return match ($this) {
            self::Story => 'السطر الأول هو نصّ قسم «من نحن» في الصفحة الرئيسية، وتظهر الأسطر كلّها في صفحة «التعريف الكامل».',
            default => null,
        };
    }

    /** المجموعة التي لكل سطر فيها مصطلح ونصّ، لا نصّ وحده. */
    public function hasTerm(): bool
    {
        return $this === self::Value;
    }
}
